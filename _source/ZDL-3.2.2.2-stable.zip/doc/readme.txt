   _________________________
  /                         /
 /   ZDL 3.2.2.2           /
/_________________________/

http://zdl.vectec.net
(C) ZDL Software Foundation

Thank you for using ZDL 3.2!
I add features based on demand and usage.  The more users
and feedback I get, the better the product gets.

Special Thanks:
- Ryan "Biohazard" Turner, original ZDL artwork/designer/coder
- NeuralStunner, alpha tester and artwork
- Risen, Enjay, DRDTeam.org, ZDoom.org, for being awesome
- Everybody who reported bugs!

On IRC? Join us at #zdl on EsperNET - irc.esper.net

ZDL 3.2 is released under the GNU Public License v3 (GPLv3).

In short, that means:
  ...
  For the developers' and authors' protection, the GPL clearly
  explains that there is no warranty for this free software. For 
  both users' and authors' sake, the GPL requires that modified 
  versions be marked as changed, so that their problems will not 
  be attributed erroneously to authors of previous versions.
  ...


